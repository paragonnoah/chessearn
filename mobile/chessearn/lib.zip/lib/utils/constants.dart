class Constants {
  static const String accessTokenKey = 'access_token';
}